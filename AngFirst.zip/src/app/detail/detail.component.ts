import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  constructor() { }

 @Input() Notifications:string[] =[];
 @Output() Show = new EventEmitter();

 public someMore:string="Some extra data to be shared from detail component. This data is sent when the Show event is triggered";

  ngOnInit(): void {
  }
  public makeDetailVisible(){
   this.Show.emit({extras:this.someMore, id:1009});
  }

}
