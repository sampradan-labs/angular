import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
  sampleProp='Samprada';
  isDisabled=true;
  formStatus:string = "";

  onBtnClick(event:any, value:any){
    this.formStatus = "";
      console.log('The event occurred details: ');
      console.log(event);
      console.log('The #iBox contained: '+value) ;
  }
      
  changeColor(htmlControl:any){
      
      htmlControl.style = 'background-color:blue;color:yellow; pointer-events:none';
      console.log('Color changed to blue.');
  }

  submitForm(){
    this.formStatus = "Form submitted!";
  }

}
