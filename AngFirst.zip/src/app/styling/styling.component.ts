import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styling',
  templateUrl: './styling.component.html',
  styleUrls: ['./styling.component.css']
})
export class StylingComponent implements OnInit {
 
  public imgName:string = "../assets/mandalam.png";

  public getImage(file:string, img:any){
    img.src = "../assets/"+file;
    img.style = "display:block";

  }

  constructor() { }

  ngOnInit(): void {
  }

}
