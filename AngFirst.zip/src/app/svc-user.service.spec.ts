import { TestBed } from '@angular/core/testing';

import { SvcUserService } from './svc-user.service';

describe('SvcUserService', () => {
  let service: SvcUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SvcUserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
