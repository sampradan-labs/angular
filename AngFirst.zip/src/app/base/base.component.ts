import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { SHtService, Posts } from '../s-ht.service';
import { SvcUserService } from '../svc-user.service';

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css']
})
export class BaseComponent implements OnInit, OnChanges, DoCheck {

  public username:string;
  public password:string;
  public status:string;
  public names:string[] = ["Eena", "Meena", "Deeka"];
  public temp:string="";
  public hooksLog:string[];
  public data:Posts[] = [];
 
  constructor(public svc:SHtService, loginService:SvcUserService) {
    this.username = "admin";
    this.password = "1232345";
    this.status = "Not yet processed";
    this.hooksLog = []; 
    
    loginService.Login("admin", "nimda");
   }

  public AddName():void{
    this.names.push(this.temp);
  }

  public Login():void{
    if (this.username == 'admin' && this.password=='nimda') {

      this.status = "Login Successful";
    }
    else {
      this.status = "Login Failed";
    }
  }

  public ChangePassword():void{
    this.password = "changedOne!";
  }

  

  ngOnInit(): void {
    this.hooksLog.push("In the ngOnInit Phase");
    this.svc.GetWithParams().subscribe(output=>this.data = output);
  }

  ngOnChanges(changes: SimpleChanges): void {
    let propName = changes["username"];
    let currentValue = propName.currentValue;
    let previousValue = propName.previousValue;
    this.hooksLog.push(`Username property has current Value = ${currentValue} and previous value = ${previousValue}In the ngOnChanges Phase`);
  }

  ngDoCheck(): void {
    this.hooksLog.push("ngDoCheck phase");
  }

}
