import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseJwtComponent } from './use-jwt.component';

describe('UseJwtComponent', () => {
  let component: UseJwtComponent;
  let fixture: ComponentFixture<UseJwtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UseJwtComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UseJwtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
