import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthSvcService } from '../auth-svc.service';
import { SvcUserService } from '../svc-user.service';

@Component({
  selector: 'app-use-jwt',
  templateUrl: './use-jwt.component.html',
  styleUrls: ['./use-jwt.component.css']
})
export class UseJwtComponent implements OnInit {

  form:FormGroup=this.fb.group({
    email: ['',Validators.required,Validators.email],
    password: ['',Validators.required]
});


public routeVal:string="";

  constructor(private fb:FormBuilder, 
               private userService: SvcUserService, 
               private router: Router, private routeParams:ActivatedRoute) {


  }

  ngOnInit(): void {
    this.routeParams.params.subscribe(params=>this.routeVal=params['id']);
  }

  login() {
      const val = this.form.value;

      if (val.email && val.password) {
          this.userService.Login(val.email, val.password)
              .subscribe(
                  () => {
                      console.log("User is logged in");
                      this.router.navigateByUrl('/if/guarded/route');
                  }
              );
      }
  }
  logout(){
    this.userService.logout();
  }

  

}
