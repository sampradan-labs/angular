import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BaseComponent } from './base/base.component';
import { StylingComponent } from './styling/styling.component';
import { OverviewComponent } from './overview/overview.component';
import { DetailComponent } from './detail/detail.component';
import { BuiltinPipesComponent } from './builtin-pipes/builtin-pipes.component';
import { ReversePipe } from './reverse.pipe';
import { CustomPipesComponent } from './custom-pipes/custom-pipes.component';
import { TemplateFormComponent } from './template-form/template-form.component';
import { RFormComponent } from './r-form/r-form.component';
import { UserDataComponent } from './user-data/user-data.component';
import { AuthSvcService } from './auth-svc.service';
import { UseJwtComponent } from './use-jwt/use-jwt.component';
import { ForIfComponent } from './for-if/for-if.component';
import { HighlightDirective } from './highlight.directive';
import { UseDirectiveComponent } from './use-directive/use-directive.component';
import { DynamicFormsComponent } from './dynamic-forms/dynamic-forms.component';


@NgModule({
  declarations: [
    AppComponent,
    BaseComponent,
    StylingComponent,
    OverviewComponent,
    DetailComponent,
    BuiltinPipesComponent,
    ReversePipe,
    CustomPipesComponent,
    TemplateFormComponent,
    RFormComponent,
    UserDataComponent,
    UseJwtComponent,
    ForIfComponent,
    HighlightDirective,
    UseDirectiveComponent,
    DynamicFormsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [{  
    provide: HTTP_INTERCEPTORS,  
    useClass: AuthSvcService,  
    multi: true  
  } ],
  bootstrap: [BaseComponent]
})
export class AppModule { }
