export class User {
    public username:string="";
    public  password:string="";
    public name:string="";
    public age:number=18;    
    public id:number = 0;
    public email:string="";
    public address:any = {};
    public phone:string="";
    public website:string="";
    public company:any={};
    public idToken:string="";
}
