import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-if',
  templateUrl: './for-if.component.html',
  styleUrls: ['./for-if.component.css']
})
export class ForIfComponent implements OnInit {

  constructor() { }
  public condition:boolean=true;
  ngOnInit(): void {
  }

  public onChange(){
    this.condition = !this.condition;
  }

}
