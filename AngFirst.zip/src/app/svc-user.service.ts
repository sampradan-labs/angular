import { Injectable } from '@angular/core';
import { User } from './user';
import { HttpClient } from '@angular/common/http';
import * as moment from 'moment';
import { tap, map } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SvcUserService {
  public users:User[] = [];
  constructor(public http:HttpClient) { } //To convert a parameter to a property add an access-specifier
  public output:User[] = [];
  public GetAllUsers_Promise_Http(){
      //Make a call to a server application
      //asp.net, java app
      //Done thru ajax
      var result:User[]=[];         
     return this.http.get<User[]>("https://jsonplaceholder.typicode.com/users")
                .toPromise();
                      
  }

  public GetAllUsers_Promise_ES(){
    return fetch("https://jsonplaceholder.typicode.com/users")
    .then(response=> response.json())
  }

  public GetAllUsers_Observable_Http(){
    return this.http.get<User[]>("https://jsonplaceholder.typicode.com/users");
  }

  public GetAllPosts_Observable_Http(){
    return this.http.get("https://jsonplaceholder.typicode.com/posts");
  }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  public Login(username:string, password:string)
  {

    // return of(this.http.post<User>('https://jsonplaceholder.typicode.com/users', {username:username, password:password})    
    //         .subscribe(res => {
    //                            res.idToken = "falskdfj239fkjadfhiwukerskdjfhaskjdfhskjfhaskjfhaskjfhwaleurer";
    //                            this.setSession(res)}))
    return of(this.http.get<User>('http://localhost:3000/users/1')    
            .subscribe(res => {
                               this.setSession(res)}))

           
  }

  private setSession(authResult:any) {
    const expiresAt = moment().add(authResult.expiresIn,'second');

    localStorage.setItem('id_token', authResult.idToken);
    localStorage.setItem("expires_at", JSON.stringify(expiresAt.valueOf()) );
    console.log(localStorage.getItem('id_token'));
    console.log(localStorage.getItem('expires_at'));
} 

logout() {
  localStorage.removeItem("id_token");
  localStorage.removeItem("expires_at");
}

public isLoggedIn() {
  return moment().isBefore(this.getExpiration());
}

isLoggedOut() {
  return !this.isLoggedIn();
}

getExpiration() {
  const expiration:string = <string>localStorage.getItem("expires_at");
  const expiresAt = JSON.parse(expiration);
  return moment(expiresAt);
}
}
