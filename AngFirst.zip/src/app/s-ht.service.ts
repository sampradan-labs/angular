import { Injectable } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from "@angular/common/http";

const reqHeaders = new HttpHeaders()
                          .set("Access-Control-Allow-Origin", "*");

@Injectable({
  providedIn: 'root'
})
export class SHtService {

  constructor(private objHttp: HttpClient) { }

  GetWithParams(){
    // http://localhost:3000/Customers?_page=1&_limit=1
  const params = new HttpParams().set('_page',"1")
                                 .set('_limit',"1");
  
  return this.objHttp.get<Posts[]>("https://jsonplaceholder.typicode.com/posts");
              
}
}
export class Posts{
  userId:any;
  title:any;
  body:any;
}