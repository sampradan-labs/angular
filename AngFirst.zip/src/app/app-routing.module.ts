import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailComponent } from './detail/detail.component';
import { DynamicFormsComponent } from './dynamic-forms/dynamic-forms.component';
import { ForIfComponent } from './for-if/for-if.component';
import { OverviewComponent } from './overview/overview.component';
import { RFormComponent } from './r-form/r-form.component';
import { RouteGuardService } from './route-guard.service';
import { TemplateFormComponent } from './template-form/template-form.component';
import { UseDirectiveComponent } from './use-directive/use-directive.component';
import { UseJwtComponent } from './use-jwt/use-jwt.component';

export const router: Routes = [
  { path: '', redirectTo: 'overview', pathMatch: 'full' },
  { path: 'jwt/:id', component: UseJwtComponent },
  { path: 'overview', component: OverviewComponent },
  {path: 'directive', component:UseDirectiveComponent},  
  {path:'dynamic/form', component:DynamicFormsComponent},
  { path: 'if/guarded/route', component: ForIfComponent, canActivate: [RouteGuardService]},
  {path:'lazy/load/m2', component: DetailComponent ,loadChildren: () => import('./m2-project/m2-project.module').then(m => m.M2ProjectModule)},
  {path: 'form/:id', component:TemplateFormComponent, 
        children:[
          {path: '', redirectTo:'rform', pathMatch: 'full'},
          {path: 'rform', component:RFormComponent}          
        ]}
];

@NgModule({
  imports: [RouterModule.forRoot(router)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
