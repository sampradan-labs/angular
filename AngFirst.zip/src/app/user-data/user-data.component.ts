import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { SubscriptionLike } from 'rxjs/internal/types';
import { SvcUserService } from '../svc-user.service';
import { User } from '../user';
@Component({
  selector: 'app-user-data',
  templateUrl: './user-data.component.html',
  styleUrls: ['./user-data.component.css']
})
export class UserDataComponent implements OnInit, OnDestroy {

  constructor(public UserSvc:SvcUserService) { }  //constructor injection
  public users:User[]=[]; //property injection
  public result:any[]=[]
  public posts:any[]=[];
  public subscriptions:Subscription = new Observable().subscribe();
  
  ngOnInit(): void {
    // this.UserSvc.GetAllPosts_Observable_Http()
    //             .subscribe(async data => this.posts = await <any>data);              

    this.subscriptions = this.UserSvc.GetAllUsers_Observable_Http()
                        .subscribe(data => this.posts = data);
    this.subscriptions.add(this.UserSvc.GetAllPosts_Observable_Http()
                    .subscribe());    
    

    //what is there in subscriptions
    console.log(this.subscriptions);

    this.UserSvc.GetAllUsers_Promise_ES().then(data => {
      for(var i=0; i< (<any[]>data).length; i++)
          {
            console.log(`Name: ${(<any>data)[i].name}`);
            this.result = <any>data;
          }  
          
    });


    this.UserSvc.GetAllUsers_Promise_Http().then(
                  data => this.users = data
                )

    
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe(); 
  }

}
