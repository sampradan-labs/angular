import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { urlValidator } from '../custom-validator.directive';

@Component({
  selector: 'app-dynamic-forms',
  templateUrl: './dynamic-forms.component.html',
  styleUrls: ['./dynamic-forms.component.css']
})
export class DynamicFormsComponent implements OnInit {

  public formdata:any[] = [
    {"label":"FirstName"},
    {"label":"LastName"},
    {"label":"Contact"},
    {"label":"Email"},
  ];

  public address:boolean = false;
  public ContactForm:FormGroup=new FormGroup({});
  public form:any=[];
  public setSettings(formdata:any[], address?:boolean, isurl?:boolean){
    
    if(this.address){
      formdata.push({"label": "Address"});
    }

    for(let i=0;i<formdata.length;i++){
        this.form[formdata[i].label] = new FormControl('',[Validators.required]);
    }
    this.ContactForm = new FormGroup(this.form);
  }

  constructor() { }

  ngOnInit(): void {
    this.setSettings(this.formdata);
  }

  public onSubmit(){

  }

  public AddTextBox(){
    this.formdata.push({"label":"Url"});    
    this.ContactForm.addControl("Url", new FormControl('',[Validators.required, urlValidator()]));

  }

 

}
