import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

/** A hero's name can't match the given regular expression */
export function urlValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (!control.value.startsWith('https') || !control.value.includes('.co')) {
      return { validUrl: {value: control.value} };
    }
    return null;

  };
}
