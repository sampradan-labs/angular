import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})
export class OverviewComponent implements OnInit {

  constructor() { }
  //Normal properties
  public name:string = "Sharayu Potuwar"
  public profileType:string = "FB Page";
  public model:any = {};

  //To be bound to detail component
  public fbNotifications:string[] = [];

  public format(data:any){
    this.model = data;
    this.fbNotifications.push("Hema Malini has accepted your friend request");
    this.fbNotifications.push("Your post has 1k likes");
    this.fbNotifications.push("You may know the person Shahrukh Khan");
  }
  ngOnInit(): void {
  }

}
