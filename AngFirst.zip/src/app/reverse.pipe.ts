import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverse'
})
export class ReversePipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    let strValue:string = <string>value;
    let result:string = ""; //hello
    for(var i = strValue.length-1; i>=0; i--){
      result += strValue[i];
    }
    if(args[0] == true){
      var uResult = result.toUpperCase();
      return uResult;
    }
    return result;
  }

}
