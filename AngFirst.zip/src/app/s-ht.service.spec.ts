import { TestBed } from '@angular/core/testing';

import { SHtService } from './s-ht.service';

describe('SHtService', () => {
  let service: SHtService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SHtService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
