/* math operations
  1. number Add(<any number of args) : Add should be able to add numbers & concatenate strings
  2. number Subtract(n1,n2)
  3. number Multiply(<any number of args>)
  4. number Divide(numerator, denominator)
 */

  /* GHERKIN
  FEATURE: Add numbers
  SCENARIO: To add valid numbers given as input
  GIVEN: Parameter list in example section
  WHEN: Add() is called
  THEN: It should return a valid result as given in the example
  EXAMPLE:
          |INPUT        | EXPECTED OUTPUT |
          | 10,20,30    | 60              |
          | 20.5, 10.5  | 31              |
          | 100         | 100             |
    
  FEATURE: Divide numbers
  SCENARIO: To divide numbers with unusual / erroneous inputs
  GIVEN: Parameter list in example section
  WHEN: MathOps.Divide() is called
  THEN: It should return a result as given in the example
  EXAMPLE:
          |INPUT        | EXPECTED OUTPUT |
          | 0,100       | 0              |
          | 100, 0      | Error('Divide By Zero')              |
          | undefined ,100         | undefined            |
          | 100, undefined | Error('Invalid input') |
   */

  import { MathOps } from "./math-ops";

  describe('Working with MathOps', () => {
     describe('FEATURE: Add numbers', () => {
       describe('SCENARIO: To add valid numbers given as input', () => {
         describe('GIVEN: Collection of valid parameters', () => {
          // EXAMPLE:
          // |INPUT        | EXPECTED OUTPUT |
          // | 10,20,30    | 60              |
          // | 20.5, 10.5  | 31              |
          // | 100         | 100             |

          describe('It should return a valid result as given in the expected output of the example', () => {
            it('should add 10,20,30 to produce 60', () => {
              //AAA
              //Act
              let actualResult = MathOps.Add(10,20,30);
              let expectedResult = 60;

              //Assert
              expect(actualResult).toEqual(expectedResult);
            });

            it('should concatenate "hello ", "how are you" to 0hello how are you', () => {
              expect(MathOps.Add("hello ","how are you")).toEqual('hello how are you');
            });

            it('should add 20.5, 10.5 to produce 31', () => {
              expect(MathOps.Add(20.5,10.5)).toEqual(31);
            });

            it('should add 100 to produce 100', () => {
              expect(MathOps.Add(100)).toEqual(100);
              
            });
          });
           
         });
       });
     });

     describe('FEATURE: Divide Numbers', () => {
       describe('SCENARIO: To divide numbers with unusual / erroneous inputs', ()=>{
        // EXAMPLE:
        // |INPUT        | EXPECTED OUTPUT |
        // | 0,100       | 0              |
        // | 100, 0      | Error('Divide By Zero')              |
        // | undefined ,100         | undefined            |
        // | 100, undefined | Error('Invalid input') |

        it('should divide 0,100 to produce 0', () => {
          //AAA
          expect(MathOps.Divide(0,100)).toBe(0);
        });

        it('should divide 100, 0 to produce Error("Divide By Zero")', () => {
          //AAA
          expect(()=>MathOps.Divide(100,0)).toThrowError('Divide By Zero');
        });

        it('should divide undefined,100 to produce undefined', () => {
          //AAA
          expect(MathOps.Divide(undefined,100)).toBeUndefined();
        });

        it('should divide 100, undefined to produce Error("Invalid Input")', () => {
          //AAA
          expect(()=>MathOps.Divide(100,undefined)).toThrowError('Invalid Input');  //exception message verification
          expect(()=>MathOps.Divide(100,undefined)).toThrow()  //just indicates an exception
          expect(()=>MathOps.Divide(100,undefined))
               .toThrowMatching((thrown)=>thrown.stack == 'Error at Line 13, in ValidateInputs(), case denominator == undefined' );
          
        });
       })
     });


     xdescribe('FEATURE: Subtract Numbers', () => {
       it('should subtract 10, 9 to produce 1', () => {
         
       });
       it('should subtract -10,-9 to produce -19', () => {
         
       });
       it('should subtract 100 to produce as 0-100 =-100', () => {
         
       });
     });

     describe('FEATURE: Multiply numbers', () => {
       
     });

    
  });