import { TestBed } from '@angular/core/testing';

import { MyhttpService } from './myhttp.service';

/*necessary imports of files*/
import { fakeAsync } from "@angular/core/testing";
import { defer } from "rxjs";

describe('Testing http Calls', async() => {
  let httpClientSpy: { get: jasmine.Spy };  //Creating this as a jasmine spy read-only property
  let httpService: MyhttpService;
    beforeEach(()=>{
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    httpService = new MyhttpService(<any> httpClientSpy);
    })

    it('make the actual http call use fakeAsync', fakeAsync(() => {
        let expectedOutput = {
                              "userId": 1,
                              "id": 1,
                              "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                              "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
                            };

        httpClientSpy.get.and.returnValue(convertToObservable(expectedOutput));
        //make the actual call to your service method
        httpService.getDetails(100).subscribe(
            data => expect(data).toEqual(expectedOutput),
            fail => expect(fail).toThrow()
        )
    }));
});
function convertToObservable<T>(data:T): any {
      return defer(()=>Promise.resolve(data));
  }