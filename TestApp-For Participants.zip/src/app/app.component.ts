import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'TestApp';
  public place:string = "Bangalore";

  public status:string="Initial status";
  public list:string[] = [];
  public currentItem:string="";

  @Input() atInput;

  public OnClick(){
    this.status = "Clicked the button 'Click Me'";
  }

  public AddToList(){
    this.list.push(this.currentItem);
  }

  ngOnInit(): void {
      
  }

}
