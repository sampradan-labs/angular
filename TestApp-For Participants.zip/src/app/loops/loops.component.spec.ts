import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SvcEngineService } from '../svc-engine.service';

import { LoopsComponent } from './loops.component';

describe('LoopsComponent', () => {
  let classInstance: LoopsComponent;
  let testComponent: ComponentFixture<LoopsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoopsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    testComponent = TestBed.createComponent(LoopsComponent);
    
    classInstance = testComponent.componentInstance;
    testComponent.detectChanges();
  });

  it('should create', () => {
    expect(classInstance).toBeTruthy();
  });

  it('should have 3 span tags in the div html', () => {
    let htmlPart = testComponent.nativeElement;
    let spans = htmlPart.querySelectorAll('span');
    
    expect(spans.length).toEqual(3);

  });
});
