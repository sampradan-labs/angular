import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loops',
  templateUrl: './loops.component.html',
  styleUrls: ['./loops.component.css']
})
export class LoopsComponent implements OnInit {

  items=['Apples','Oranges','Mangoes']
  constructor() { }

  ngOnInit(): void {
  }

}
