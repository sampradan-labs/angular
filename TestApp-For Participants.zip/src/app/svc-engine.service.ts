import { Injectable } from '@angular/core';

 

@Injectable({
  providedIn: 'root'
})                         
export class SvcEngineService {
public make:string;
  cost: number;
  constructor() { } 
}
