import { fakeAsync, inject, TestBed, tick, waitForAsync } from '@angular/core/testing';
import {  HttpClientTestingModule,  HttpTestingController} from "@angular/common/http/testing";
import { Customer, UseHttpService } from './use-http.service';
import { defer } from 'rxjs';

/** Create async observable that emits-once and completes
 *  after a JS engine turn */
 export function asyncData<T>(data: T) {
  return defer(() => Promise.resolve(data));
}
describe('Testing Http calls with spies', async() => {
  
  let httpClientSpy: { get: jasmine.Spy };  //Creating this as a jasmine spy read-only property
  let httpService: UseHttpService;

  beforeEach(() => {
    // TODO: spy on other methods too
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    httpService = new UseHttpService(<any> httpClientSpy);
  });
  
  it('should return expected customers (HttpClient called once)', fakeAsync(() => {
    const expectedCustomers: Customer[] =
                                          [{
                                            "name": "FakeCustomer001",
                                            "email": "newcustomer001@email.com",
                                            "tel": "0000252525",
                                            "id": 1
                                          },
                                          {
                                            "id": 2,
                                            "name": "FakeCustomer002",
                                            "email": "customer002@email.com",
                                            "tel": "0527252525"
                                          }];
                                          
    //returning dummy value from mock backend                                          
    httpClientSpy.get.and.returnValue(asyncData(expectedCustomers));
  
    //Call real service
    //subscribe((data)=>{})
    httpService.GetWithParams().subscribe(
      customers => expect(customers).toEqual(expectedCustomers),
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1);
  }));

});

