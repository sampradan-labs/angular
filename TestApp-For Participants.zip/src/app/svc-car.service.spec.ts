// import { TestBed } from '@angular/core/testing';

// import { SvcCarService } from './svc-car.service';

// describe('SvcCarService', () => {
//   let service: SvcCarService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(SvcCarService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });

import { SvcCarService } from "./svc-car.service";
import { SvcEngineService } from "./svc-engine.service";

/*
FEATURE: Instantiating a Car
SCENARIO: Maruti Car is manufactured with Suzuki Engine
GIVEN: Car and Engine Services are available
WHEN: Car is instantiated with Engine object
THEN: Instantiation of Car should be successful
      Instantiation of Engine should be successful
      The make property  of Engine = Suzuki
      The make property of Car = Maruti
*/
describe('Car Manufacturing Module', () => {
  describe('FEATURE: Instantiating a Car', () => {
    describe('SCENARIO: Maruti Car is manufactured with Suzuki Engine', () => {
      it('Instantiation should be successful with dependencies and properties (car.make, car.engine.make) verification', () => {
        //Arrange
      //Act
      let eng = new SvcEngineService();
      eng.make = 'Suzuki';
      let car = new SvcCarService(eng)
      car.make = 'Maruti';

      //Assert
      expect(car).toBeTruthy();
      expect(car).toBeDefined();
      expect(car.carEngine).toBeDefined();
      expect(car.make).toEqual('Maruti');
      expect(car.carEngine.make).toEqual('Suzuki');
      });
    });
  });
});