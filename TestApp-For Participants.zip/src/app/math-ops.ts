export class MathOps {

  public static Divide(numerator: any, denominator: any): any {
    return MathOps.ValiditeInputs(numerator,denominator);
  }

  private static ValiditeInputs(numerator: number, denominator: number):any {
    if (numerator == undefined) {
      return undefined;
    }
    else if (denominator == undefined) {
      let err = new Error('Invalid Input');
      err.stack = 'Error at Line 13, in ValidateInputs(), case denominator == undefined'
      throw err;
    }
    else if(denominator == 0){
      throw new Error("Divide By Zero");
    }
    else{
      return numerator/denominator;
    }
  }

  public static Add(...pParams:number[] | string[]) : number | string
  {
    /*foreach(var single in pParams){
        result = result + single;
    } */
    let result =100;
   if(pParams.length > 0 && typeof pParams[0] == 'number'){
    let result : number = 0;
    pParams.forEach(single => {
        result += single;
    });    

    return result;
  }
  else {
    let strResult : string = '';
      pParams.forEach(single => {
          strResult += single;
      });    
  
      return strResult;
  }

}



}


