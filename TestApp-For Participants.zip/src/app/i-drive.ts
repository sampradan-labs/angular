export interface IDrive {
    drive(isAuto:boolean):string;
}

export class FourWheeler implements IDrive{
   drive(isAuto: boolean): string {
       return "Driving a four-wheeler"
   }
}

export class TwoWheeler implements IDrive{
    drive(isAuto: boolean): string {
        return 'Driving a two-wheeler';
    }
}