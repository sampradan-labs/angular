/*
FEATURE: Classes that implement IDrive should work as per their overridden behavior
SCENARIO: svcCar should execute its overridden functionality
GIVEN: A car object, car.carCost = 200000, car.carEngine.cost = 150000, 
       car.make = MARUTI,
       car.carEngine.make = 'SUZUKI'
WHEN: car object.drive() is called
THEN: Output should be The MARUTI car has the SUZUKI engine and costs INR 350000
*/
import {SvcCarService} from './svc-car.service'
import {SvcEngineService} from './svc-engine.service'
import {IDrive} from './i-drive';


describe('FEATURE: Classes that implement IDrive should work as per their overridden behavior', () => {
    describe('SCENARIO: svcCar should execute its overridden functionality', () => {
        it('should show output as "The MARUTI car has the SUZUKI engine and costs INR 350000"', () => {
            //Arrange
            let eng = new SvcEngineService();
            eng.make = 'SUZUKI';
            eng.cost = 150000;
            let car = new SvcCarService(eng, 200000)
            car.make = 'MARUTI';
            
            //Act
            let result =car.drive(true);

            //Assert
            expect(result).toEqual("The MARUTI car has the SUZUKI engine and costs INR 350000");

        });
    });
});

var obj={
          output:'',
          log: (msg)=>{console.log(msg);},
          getdetails:(id)=>{
              obj.output = `Details for person with id=${id}`
              obj.log(id);
          },
          getCost: ()=>{obj.log(1000); return 1000;}
    };

describe('FEATURE: Working with spies', () => {
   
    it('SCENARIO: should have a call made to getdetails()', () => {
        //Arrange
        spyOn(obj,'getdetails');
       
        //Act: Invoke the real function
       
        obj.getdetails(1001);
        expect(obj.getdetails).toHaveBeenCalled();
        expect(obj.getdetails).toHaveBeenCalledTimes(1);
        expect(obj.getdetails).toHaveBeenCalledWith(1001);

    });
    it('SCENARIO: should have a call made to log() when getdetails() is called', () => {
        spyOn(obj,'log');   //verifying workflow
        obj.getdetails(1001);

        expect(obj.log).toHaveBeenCalledOnceWith(1001);      
        expect(obj.log).toHaveBeenCalled();
        
        expect(obj.output).toEqual('Details for person with id=1001');
    });
    it('verify the return value', () => {
        spyOn(obj,'getCost').and.returnValue(2000); //configuration
        obj.getCost();
        expect(obj.getCost()).toEqual(2000);
    });
});