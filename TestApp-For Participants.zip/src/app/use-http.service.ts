import { Injectable } from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders}  from '@angular/common/http';

const reqHeaders = new HttpHeaders()
                          .set("Access-Control-Allow-Origin", "*");

@Injectable({
  providedIn: 'root'
})
export class UseHttpService {

  constructor(public http:HttpClient) { }
  public GetWithParams(){
    // url?_page=1&_limit=1
    
    
    
    return this.http.get<Customer[]>("http://localhost:3000/customers?_page=1&_limit=1",{headers:reqHeaders});
  }
}
export class Customer{
  public name:string;
  public email:string;
  public tel:string;
  public id;
}
