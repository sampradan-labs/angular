import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyhttpService {

  constructor(public http:HttpClient) {    

  }

  public getDetails(opt?:any){
    //....
    return this.http.get<Posts>('https://jsonplaceholder.typicode.com/posts/1');
  }
}

export class Posts{
  public userId:number;
  public id:number;
  public title:string;
  public body:string;
}