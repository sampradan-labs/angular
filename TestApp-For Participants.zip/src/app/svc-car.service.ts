import { Injectable } from '@angular/core';
import { FourWheeler } from './i-drive';
import { SvcEngineService } from './svc-engine.service';

@Injectable({
  providedIn: 'root'
})
export class SvcCarService extends FourWheeler {
  public make:string='';
 // private carCost:number=0;

  constructor(public carEngine:SvcEngineService, private carCost:number=0) { 
    super();  //Invoke the constructor of the base class    
   }
   

   drive(isAuto: boolean): string {
     
       return `The ${this.make} car has the ${this.carEngine.make} engine and costs INR ${this.Buy()}`;
   }

   public Buy():number{
     //Engine class will have a cost property
     //total cost = carCost + carEngine.cost
     /*
     FEATURE: User wants to buy a car
     GIVEN: A car Object, car.carCost = 200000, car.carEngine.cost=150000
     WHEN: Buy() is called
     THEN: The result should be car.carCost + car.carEngine.cost i.e 350000
     */
    
    return this.carCost + this.carEngine.cost;
   }

   public Validate(){
     this.drive(true);
     this.drive(false);
     if(this.carEngine == null)
        throw new Error('Car has no engine');
   }

   
}
