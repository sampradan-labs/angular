// /*necessary imports of files*/

// import { fakeAsync } from "@angular/core/testing";
// import { defer } from "rxjs";

// describe('Testing http Calls', async() => {
//   let httpClientSpy: { get: jasmine.Spy };  //Creating this as a jasmine spy read-only property
//   let httpService: <your-service>;
//     beforeEach(()=>{
//     httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
//     httpService = new yourService(<any> httpClientSpy);
//     })

//     it('make the actual http call use fakeAsync', fakeAsync(() => {
//         let expectedOutput = [{key:'value',..}];

//         httpClientSpy.get.and.returnValue(convertToObservable(expectedOutput));
//         //make the actual call to your service method
//         httpService.yourMethod(<your-params>).subscribe(
//             data => expect(data).toEqual(expectedOutput),
//             fail => expect(fail).toThrow()
//         )
//     }));
// });

// function convertToObservable<T>(data:T): any {
//     return defer(()=>Promise.resolve(data));
// }
