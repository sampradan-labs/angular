import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'TestApp'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;  //class or ts part
    expect(app.title).toEqual('TestApp');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement; //html part of component
    expect(compiled.querySelector('.content span').textContent).toContain('TestApp app is running!');
  });

  it('should have place as "Bangalore"', () => {
    let testComponent = TestBed.createComponent(AppComponent);
    let classInstance = testComponent.componentInstance;
    expect(classInstance.place).toEqual('Bangalore');
    classInstance.place = 'Pune';
    expect(classInstance.place).toEqual('Pune');
  });

  it('should render place on html', () => {
    let testComponent = TestBed.createComponent(AppComponent);
    let htmlComponent = testComponent.nativeElement;
    let classInstance = testComponent.componentInstance;
    testComponent.detectChanges();  //force databinding
    expect(htmlComponent.querySelector('.textbox').value).toContain('Bangalore');
    classInstance.place = 'Pune';
    testComponent.detectChanges();
    expect(htmlComponent.querySelector('.textbox').value).toContain('Pune');
  });

  it('should simulate click event using debugElement.query()', () => {
    let testComponent = TestBed.createComponent(AppComponent);
    let htmlComponent = testComponent.nativeElement;
    let classInstance = testComponent.componentInstance;
    var htmlPart = testComponent.debugElement;
    var btn = htmlPart.query(By.css('.btn'));
    btn.triggerEventHandler('click',{});
    expect(classInstance.status).toEqual("Clicked the button 'Click Me'");
  });

    
});
