import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public username:string;
  public pwd:string;
  @Input() status:string; //[],{{}}
  @Output() customEvent = new EventEmitter(); //()

  public login():void{
    (this.username=='admin' && this.pwd=='nimda')?
          this.status='Login succeeded':
            this.status ='Login failed';
  }

  public handler(){
    this.status='triggered custom event';
  }
  constructor() { }

  ngOnInit(): void {
  }

}
