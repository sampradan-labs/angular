import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let classInstance: LoginComponent;
  let testComponent: ComponentFixture<LoginComponent>;
  let htmlPart:any;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    testComponent = TestBed.createComponent(LoginComponent);
    classInstance = testComponent.componentInstance;
    htmlPart = testComponent.nativeElement;
    testComponent.detectChanges();
  });

  it('should create', () => {
    expect(classInstance).toBeTruthy();
  });

  /*
  GIVEN: input type=text that contains username. username =admin
         input type=password that contains password. pwd =nimda
         button with onclick event mapped to a function called login()
  WHEN: button is clicked
  THEN: status property should be equal to  'Login succeeded'
   */

  it('SCENARIO: should show status="Login succeeded" when login button is clicked', () => {
    //Arrange
    classInstance.username='admin';
    classInstance.pwd='nimda';
    //ACT
    testComponent.detectChanges();  //databind above settings to html part
    let button = htmlPart.querySelector('.login')
    button.click();
    //Assert
    testComponent.detectChanges();
    expect(classInstance.status).toEqual('Login succeeded');
    let div = htmlPart.querySelector('div');
    expect(div.textContent.trim()).toEqual('Login succeeded');
  });

  it('SCENARIO: should show status="Login succeeded" when the enter key is pressed', () => {
    //Arrange
    classInstance.username='admin';
    classInstance.pwd='nimda';
    //ACT
    testComponent.detectChanges();  //databind above settings to html part
    htmlPart = testComponent.debugElement;
    let button = htmlPart.query(By.css('.login'));
    button.triggerEventHandler('keyup.enter',{});
    //Assert
    expect(classInstance.status).toEqual('Login succeeded');
  });
});
